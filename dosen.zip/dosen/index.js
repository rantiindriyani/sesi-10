const dosenGelar = 'M.Kom'; // ganti dengan gelar dosen yang akan di edit
const updatedData = {
    nama: 'Alun Sujada',
    gender: 'L',
    prodi: 'TI',
    alamat: 'Salabintana'
};

fetch(`http://127.0.0.1:3000/dosen/${dosenGelar}`, {
    method: 'PUT',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(updatedData)
})
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));