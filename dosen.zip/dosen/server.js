const express = require('express');
const bodyParser = require('body-parser');
const dosenController = require('./controllers/dosenController'); // Ubah sesuai dengan nama file dan path yang sesuai

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

// Endpoint untuk dosen
app.use('/dosen', dosenController); // Ubah endpoint sesuai kebutuhan

// Jalankan server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});